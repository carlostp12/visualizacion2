# visualizacion2
PEC2 de visualización de datos.

Para acceder online a los contenidos de esta PEC entre en la URL:

https://carlostp12.github.io/visualizacion2/

# Información:

Esta PEC se compone de 3 ejericios:
	
	1.- Histograma: para el que hemos empleado R con R studio.
	
	2.- Proportional Symbol MAP: donde hemos usado Tableau.
	
	3.- Ridgeline charts: Donde hemos usado D3 + javascript + HTML.
	
	 
El dataset en el que está basado este estudio ha sido descargado desde:

https://www.kaggle.com/datasets/thedevastator/global-fossil-co2-emissions-by-country-2002-2022

Toda la práctica se puede descargar en:

https://carlostp12.github.io/visualizacion2/practica2.zip